<p align="center"><img src="https://i0.wp.com/images.hive.blog/DQmZgGvu6YXrMNyDb4wVURLV14WNNSYs58R1kY64HNMSmCL/hive-didver1.gif"></p>
غير مبري الذمة الي ياخذله حرف واحد وينسبه لنفسه ويكول من كتابتي خصيمه يوم القيامه
تريد تسرق اذكر مصدر الكود منين وكافي تضحك ع العالم ع ساس انته مسويه

original source code: https://github.com/TgCatUB/catuserbot
<p align="center"><img src="https://i0.wp.com/images.hive.blog/DQmZgGvu6YXrMNyDb4wVURLV14WNNSYs58R1kY64HNMSmCL/hive-didver1.gif"></p>
